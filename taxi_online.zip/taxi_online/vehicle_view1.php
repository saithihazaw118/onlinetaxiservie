<?php 
	session_start();
	include 'connection.php';

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Vehicle View</title>
<link rel="stylesheet" type="text/css" href="vehicleview1.css">
</head>
<body>
 <form> 

 		
 	<?php 
 	 $vehicle="SELECT VehicleID, Type, Vehicle_License FROM vehicle";
     $vehicledata=mysqli_query($connection,$vehicle);
 	$vehicletotal=mysqli_num_rows($vehicledata);  
 		?>

 	<table border="2" align="center" class="second">
 		<tr>
 			<th>Type</th>
 			<th>Vehicle License</th>	  
 			<th>Choose</th>
 		</tr>

 		<?php 	if ($vehicletotal !=0  )
 				{   
 		?>

 		<?php 
 		 	while ($vehicleresult=mysqli_fetch_assoc($vehicledata)) 
 		 		{
 		 	echo " 
 			<tr>
 				<td>".$vehicleresult['Type']."</td>
 				<td>".$vehicleresult['Vehicle_License']."</td>
 				<td><a href='vehicleaccept1.php?Type=$vehicleresult[Type] &
 							VehicleID=$vehicleresult[VehicleID] &
 							Vehicle_License=$vehicleresult[Vehicle_License] '>Click</a></td>	
 			</tr> "; } }
 		?>

 <?php 
 	 $query="SELECT * FROM driver";
     $data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data);  
 		?>

 	<table border="2" class="first">
 		<tr>
 			<th>Name</th>
 			<th>Phone Number</th>	
 			
 		</tr>

 		<?php 	if ($total !=0  )
 				{   
 		?>

 		<?php 
 		 	while ($result=mysqli_fetch_assoc($data)) 
 		 		{
 		 	echo " 
 			<tr>
 				<td>".$result['Name']."</td>
 				<td>".$result['Phone_Number']."</td>
 				
 			</tr> "; } }
 		?>
 			
 	</table>

 	</table>
 	

 </form>
</body>
</html>

