<?php 
  session_start();
  include 'connection.php';

   $_GET['UserID'];
  $_GET['FullName'];
  $_GET['Date_of_Birth'];
  $_GET['Password'];
  $_GET['Email'];
  $_GET['Address'];
  $_GET['PhoneNumber'];
   $_GET['Gender'];



  if(isset($_GET['btnUpdate']))
   {

    $userid=$_GET['UserID'];
    $fullname=$_GET['FullName'];
    $dob=$_GET['Date_of_Birth'];
    $pass=$_GET['Password'];
    $email=$_GET['Email'];
    $address=$_GET['Address'];
    $phonenumber=$_GET['PhoneNumber'];
     $gender=$_GET['Gender'];

   $query= "UPDATE userregister SET UserID='$userid',
                                    FullName='$fullname',
                                    Date_of_Birth='$dob',
                                    Password='$pass',
                                    Email='$email',
                                    Address='$address',
                                    PhoneNumber='$phonenumber',
                                    Gender='$gender'
                                    WHERE UserID='$userid' ";

   $data=mysqli_query($connection,$query);

       if ($data)
       {
        echo "<script>alert('Data Updated');window.location.href='userdata.php';</script>";
       }  

      else
      {
         echo "<font color='red'>Update Failed,Try Again </font> ";
      }
}   


 ?>

 <!DOCTYPE html>
 <html>
 <head>
   <title>Update File</title>
 </head>

 <body>
    <form action="updateform.php" method="GET" enctype="multipart/form-data" id="updateform">

      <table align="center" cellpadding="2px" border="2px">

        <tr>
          <td >UserID</td>
          <td bgcolor="red" ><input type="text" name="UserID" value="<?php echo $_GET['UserID']; ?>" readonly></td>
        </tr> 

        <tr>
          <td>Full Name</td>
          <td><input type="text" name="FullName" value="<?php echo $_GET['FullName']; ?>" ></td>
        </tr>

       <tr>
         <td>Date of Birht</td>
         <td><input type="text" name="Date_of_Birth" value="<?php echo $_GET['Date_of_Birth']; ?>" ></td>
       </tr>

        <tr>
       <td>Password:</td>
       <td> <input type="text" name="Password" required="" value="<?php echo $_GET['Password']; ?>"> </td>
       </tr>

       <tr>
         <td>Email :</td>
         <td ><input type="Email" name="Email" value="<?php echo  $_GET['Email']; ?>" ></td>
       </tr>
       
       <tr>
          <td>Address:</td>
          <td ><input type="text" name="Address" value="<?php echo $_GET['Address'];?>"  ></td>
        </tr>
        <tr>
          <td>Phone Number</td>
          <td ><input type="ID" name="PhoneNumber" value="<?php echo $_GET['PhoneNumber']; ?>"  ></td>
        </tr>

       <tr>
         <td>Gender</td>
         <td>Male <input type="radio" name="Gender" value="Male" required
          <?php 
            if ( $_GET['Gender'] == "Male") 
            {
              echo "checked";
            }
           ?>
          >
          Female <input type="radio" name="Gender" value="Female" required
           <?php 
            if ($_GET['Gender'] == "Female") 
            {
              echo "checked";
            }
           ?>
          >
        </td>

       </tr>
          
          <tr align="center">
                <td><input type="submit" name="btnUpdate" value="Update"></td>
               <td> <input type="button" value="Back!" onclick="history.back()"> </td>
                
          </tr>
        
    </table>
        
  </form>
  <table align="center">
   <tr><td>
  <a href="stafflogin.php"><h2><i>Back To Home Page</i></h2> </a></td></tr>
  </table>
 </body>