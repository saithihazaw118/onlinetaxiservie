<?php 
session_start();
include 'connection.php';	
	 	
 $_SESSION['UserID'];
 $_SESSION['FullName'];

$query="SELECT * FROM userregister where UserID='$_SESSION[UserID]'";
 $data=mysqli_query($connection,$query);
    $total=mysqli_num_rows($data);
 
	if (isset($_POST['btnrent']))

	{
		$UserID=$_SESSION['UserID'];
		$FullName=$_SESSION['FullName'];
		$Pickup=$_POST['Pick_up_address'];
		$Dropoff=$_POST['Drop_off_address']; 
		$Fees=$_POST['txtfees'];
		

		$private= "INSERT into private_rent(UserID,FullName,Pick_up_address, Drop_off_address,Fees)
		values('$UserID','$FullName','$Pickup','$Dropoff','$Fees')";	
		$query=mysqli_query($connection,$private);
		if($private)
		{
			echo "<script>alert('Rent Successful.Driver is coming Your place. Thank You.') 
			window.location='waiting.php'</script>";
			 
		}
		
      else
       {
         mysqli_error($connection); 
       }

          function ClearText()
         {
          txtpickup.Text =="";
          txtdropoff.Text=="";
          txtfees.Text=="";
          
        }


}


$select="SELECT * from userregister";
    $run=mysqli_query($connection,$select);
    $count=mysqli_num_rows($run);
	if ($count>0)
     	{
         $row=mysqli_fetch_array($run);
         $UserID=$row[0];
        
	     }

	     $query="SELECT * FROM userregister u, private_rent p
			WHERE u.UserID=p.UserID
		   ";
    $data=mysqli_query($connection,$query);
    $total=mysqli_num_rows($data);

 ?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="private.css">
	 <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<title>Private Rent</title>
	
</head>
<body style="width: 100%;margin: auto;">
	<form action="privaterent.php" method="POST"> 
		<table class="table1">
			<tr><td class="upd"><a href="header.php"><i class="fa fa-reply">Back</i></a></td></tr>
		</table>

		<table class="table2" align="center">
	
			
			<tr rowspan="2">
				<th class="th">User Name</th>
				<th><input type="text" class="update" name="txtfullname" readonly value="<?php echo $_SESSION['FullName'] ?>"></th>

				<th class="th">Pick-up address</th>
				<th><textarea type="text" class="update" name="Pick_up_address" required> </textarea></th>
			</tr> 
			<tr>

				<th class="th">Fees</th>
				<th><input type="text" class="update" name="txtfees" required="Please fill Fees" placeholder="..Kyat.."></th>

				<th class="th">Drop-off address</th>
				<th><textarea type="text" class="update" name="Drop_off_address" required="Please fill Drop of address"></textarea></th>
			 </tr>

				
			
			<tr align="center">
				<td ><input type="submit" name="btnrent" value="Rent" class="btnn"></td>
				<td><input type="reset" name="btncancel" class="btnn" value="Cancel" onclick="ClearText();" ></td>

			</tr>

		</table>

		
		<table class="table3">
			
				
				<td><div id="wrapper-9cd199b9cc5410cd3b1ad21cab2e54d3">
		<div id="map-9cd199b9cc5410cd3b1ad21cab2e54d3"></div><script>(function () {
        var setting = {"height":658,"width":710,"zoom":12,"queryString":"Yangon, Myanmar (Burma)","place_id":"ChIJaxk-Ip6UwTARtAsI-HHS-1Y","satellite":false,"centerCoord":[16.81171800237581,96.2285064815323],"cid":"0x56fbd271f8080bb4","lang":"en","cityUrl":"/myanmar/yangon-32900","cityAnchorText":"Map of Yangon, Yangon Region, Myanmar","id":"map-9cd199b9cc5410cd3b1ad21cab2e54d3","embed_id":"329975"};
        var d = document;
        var s = d.createElement('script');
        s.src = 'https://1map.com/js/script-for-user.js?embed_id=329975';
        s.async = true;
        s.onload = function (e) {
          window.OneMap.initMap(setting)
        };
        var to = d.getElementsByTagName('script')[0];
        to.parentNode.insertBefore(s, to);
      })();</script><a href="https://1map.com/map-embed">1 Map</a></div>

</td>

			
 	
 		
 	
 	
 	
	
		
			</table>
			

	</form>
</body>
</html>

 <?php  
 include 'footer.php';
  ?>
		