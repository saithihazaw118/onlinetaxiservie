	<?php 
	session_start();
	include 'connection.php';
	$UserID=$_SESSION['UserID'];

   	
 		$query="SELECT * FROM userregister where UserID='$UserID' ";
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 

 	 
 		

 		

 		while ($result=mysqli_fetch_assoc($data))
			 {	

			 			$UserID=$result['UserID'];
 						$FullName=$result['FullName'];
 						$Date_of_Birth=$result['Date_of_Birth'];
 						$Password=$result['Password'];
 						$Email=$result['Email'];
 						$Address=$result['Address'];
 						$PhoneNumber=$result['PhoneNumber'];
 						$Gender=$result['Gender'];
 						

 			
 		}
 	

?>
 



 <!DOCTYPE html>
 <html>
 <head>
 	 <link rel="stylesheet" type="text/css" href="myinformation.css">
 	 <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title>User Data</title>
 </head>
 <body >
<div class="header"><h2>My Information</h2></div>
 <form> 

 	
 		
 
		

		<table>

		<div class="input-group">
        	<label>User ID</label>
       		 <input type="text" name="UserID" readonly value="<?php echo $UserID ?>" > 
     	</div>

     <div class="input-group">
        <label>Full Name</label>
         <input type="text" name="FullName" readonly  value="<?php echo $FullName ?>" > 
     </div>

     <div class="input-group">
        <label>Date of Birth</label>
         <input type="text" name="Date_of_Birth" readonly  value="<?php echo $Date_of_Birth ?>" >
     </div>

     <div class="input-group">
        <label>Password</label>
         <input type="text" name="Password" readonly  value="<?php echo $Password ?>" >
     </div>

     <div class="input-group">
        <label>Email</label>
        <input type="text" name="Email" readonly  value="<?php echo $Email ?>" >
     </div>

     <div class="input-group">
        <label>Address</label>
       <input type="text" name="Address" readonly value="<?php echo $Address ?>" >
     </div>

     <div class="input-group">
        <label>Phone Number</label>
        <input type="text" name="PhoneNumber" readonly  value="<?php echo $PhoneNumber ?>" >
     </div>

     <div class="input-group">
        <label>Gender</label>
       <input type="text" name="Gender" readonly  value="<?php echo $Gender ?>" >
     </div>

     <div class="input-group">
     <label class="upd">	<?php    echo "<a href='userupdateform.php?UserID=$UserID &
 							FullName=$FullName &
 							Date_of_Birth=$Date_of_Birth &
 							Password=$Password &
 							Email=$Email &
 							Address=$Address &
 							PhoneNumber=$PhoneNumber &
 							Gender=$Gender'>Edit</a>";  	?> </label>
	 </div>

     <div> 
 	<label class="upd1"><a href="header.php"><i  class="fa fa-reply">Back</i></a></label> 
	</div>
 			
 	</table>

		

<!-- <footer>
	
   <div class="middle">
 		
 	<a class="btn" href="https://www.facebook.com/">
 		<i class="fa fa-facebook-official"></i>
 	</a>
 	<a class="btn" href="https://www.facebook.com/">
 		<i class="fa fa-twitter-square"></i>
 	</a>
 	<a class="btn" href="https://www.google.com/">
 		<i class="fa fa-google"></i>
 	</a>
 	<a class="btn" href="https://www.instagram.com/">
 		<i class="fa fa-instagram"></i>
 	</a>
 	
	</div>

 </footer> -->
	


 </form>
 </body>
 </html> 
 <?php include'footer.php'; ?>