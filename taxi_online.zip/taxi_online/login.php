<?php 
  session_start();
  include('connection.php');
  
if(isset($_POST['btnlogin'])) 
{
  $txtEmail=$_POST['email'];
  $txtPW=$_POST['password'];


  $admin="SELECT * FROM userregister 
        WHERE Email='$txtEmail'
        AND Password='$txtPW'";

  
  $result=mysqli_query($connection,$admin); 
  $count= mysqli_num_rows($result);
  $array=mysqli_fetch_array($result);

 
 if  ($count<1)
    {
      if (isset($_SESSION['count']))
      {
        $_SESSION['count']++;
      } 
      else
      {
        $_SESSION['count']=1;
      }
      echo "<script>window.alert('Email or Password is Incorrect. Please try again.')</script>";
      echo "<script>window.location='login.php'</script>";
    } 
     else
    {
    
    $_SESSION['UserID']=$array['UserID'];
     $_SESSION['FullName']=$array['FullName'];
    $_SESSION['Email']=$array['Email'];
    $_SESSION['Password']=$array['Password'];
    $_SESSION['Date_of_Birth']=$array['Date_of_Birth'];
    $_SESSION['Address']=$array['Address'];
    $_SESSION['PhoneNumber']=$array['PhoneNumber'];
    $_SESSION['Gender']=$array['Gender'];


   

    $Name=$array['FullName'];
    echo "<script>window.alert('Welcome $Name ')</script>";
    echo "<script>window.location='header.php'</script>";

  }
 
} 

?>

<!DOCTYPE html>
 <html>
 <head>
  <title> Login Form</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="logincss.css">
   <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  
 </head>
 <body>
  

    <img class="wave">
    <div class="container">
      <div class="img">
      <img src="taxi.svg">  
    </div>

    <div class="login-container">
      <form action="login.php" method="POST">
        <img class="avatar" src="avatar.svg">
        <h2>Login Here</h2>
        
        <div class="input-div one focus">
          <div class="i">
            <i class="fa fa-envelope"></i>
          </div>
          <div>
            <h5>Email</h5>
            <input type="taxt" name="email" placeholder="Email" required class="input">
          </div>
        </div>

        <div class="input-div two">
          <div class="i">
            <i class="fa fa-key"></i>
          </div>
          <div>
            <h5>Password</h5>
            <input type="Password" name="password" placeholder="Password" required class="input">
          </div>
        </div>

        <div>
          <input type="submit" class="btn" name="btnlogin" value="Login" >
           <h5> <a href="userregister.php">Create New Account</a> </h5>
        </div>

      </form>
       </div>
       
        </div>
<script type="text/javascript" src="main.js"></script>
 </body>
 </html>
