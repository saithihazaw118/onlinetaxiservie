	<?php 
	session_start();
	include 'connection.php';



 		$query="SELECT * FROM userregister";
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 

 	 
 		if ($total !=0) 
 		{
 			?>  

 				<table align="center" cellpadding="5px" style="color:white">
		<tr style="color:lime">
 			<th>UserID</th>
 			<th>Full Name</th>
 			<th>Date of Birth</th>
 			<th>Password</th>
 			<th>Email</th>
 			<th>Address</th>
 			<th>Phone Number</th>
 			<th>Gender</th>
 			
 		</tr>
 
 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr>
 						<td>".$result['UserID']."</td>
 						<td>".$result['FullName']."</td>
 						<td>".$result['Date_of_Birth']."</td>
 						<td>".$result['Password']."</td>
 						<td>".$result['Email']."</td>
 						<td>".$result['Address']."</td>
 						<td>".$result['PhoneNumber']."</td>
 						<td>".$result['Gender']."</td>
 						
 				</tr>  " ;
 		}
 	}

  ?> 



 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="userdata.css">
 	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title>User Data</title>
 </head>
 <body>

 	<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
</header>

 </body> 
 </html> 
