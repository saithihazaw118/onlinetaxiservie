<?php 

	session_start();
	include 'connection.php';


	$Name=$_GET['Name'];
	$Phone_Number=$_GET['Phone_Number'];
	$StaffID=$_GET['StaffID'];
	$Email=$_GET['Email'];

	


	$insert="INSERT INTO using_vehicle(StaffID,Name,Email,Phone_Number)
			values ('$StaffID','$Name','$Email','$Phone_Number')";

			 if (mysqli_query($connection,$insert)) 
			 {
		echo "<script>alert('Driver Selected.') </script>";
	 		} 
	 	else 
	 		{
		echo "Error: " . $insert . "" . mysqli_error($connection);
	 		}
 

	 			$sql="DELETE FROM driver WHERE StaffID='$StaffID' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script> window.location='vehicle_view1.php'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);
		
 ?>

 
