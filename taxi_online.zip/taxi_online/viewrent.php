		<?php
 session_start();
 
include 'connection.php';
  $email=$_SESSION['Email'];
   

?>

<?php 
	$query="SELECT * FROM private_rent";
    $data=mysqli_query($connection,$query);
    $total=mysqli_num_rows($data);

     if ($total != 0) 
    {
    	?>

    	<table class="table1" align="center" cellpadding="5px" style="color:white">
		<tr style="color:black">
			<th>RentID</th>
			<th>Pick Up Address</th>
			<th>Drop off Address</th>
			<th>Fees</th> 
			
			<th>Action</th>
		</tr>
		<?php 

			while ($result=mysqli_fetch_assoc($data))
			 {
				echo "<tr>

					<td>".$result['RentID']."</td>
					<td>".$result['Pick_up_address']."</td>
					<td>".$result['Drop_off_address']."</td>
					<td>".$result['Fees']."</td>
					<td><a href='accept.php?RentID=".$result['RentID']."' > Accept </a> </td>
					</tr>";

			}
		
    }

 
 ?>

 <!DOCTYPE html>
 <html>
 <head>

 	<link rel="stylesheet" type="text/css" href="viewrent.css"> 
 	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title></title>
 </head>
 <body>
 <form>
 	<table class="table" align="center" >
 		<tr>
 			<th class="update"><a href="driverhistory.php">View History</a></th>

 			<th class="upd"><a href="stafflogin.php">Logout</a></th>
 			  
 		</tr>
 		<tr>
 			 <div class="welcome-text">
			<h1><?php 
			$Email=$_SESSION['Email'];
		
		if(isset($_SESSION['Email']))
{
	$Email=$_SESSION['Email']; 

	$query="SELECT * FROM staffregister where Email='$Email'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 

 	while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$Name= $result['Name'];
			 	echo "Welcome $Name";
			 }
}
  
			 ?></h1>
		</div>
 		</tr>
 	</table>

 	<!-- <footer>
	
   <div class="middle">
 		
 	<a class="btn" href="#">
 		<i class="fa fa-facebook-official"></i>
 	</a>
 	<a class="btn" href="#">
 		<i class="fa fa-twitter-square"></i>
 	</a>
 	<a class="btn" href="#">
 		<i class="fa fa-google"></i>
 	</a>
 	<a class="btn" href="#">
 		<i class="fa fa-instagram"></i>
 	</a>
 	
	</div>
 </footer> -->
 </form>
 </body>
 </html>

