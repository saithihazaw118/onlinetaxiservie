<?php 
	session_start();
	include 'connection.php';

?>

<!DOCTYPE html>
<html>
<head>
	<title>Admin Home</title>
	<link rel="stylesheet" type="text/css" href="adminhome.css">
</head>
<body > 
	<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a> 
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>

		<div class="welcome-text">
			<h1><?php 
			$Email=$_SESSION['Email'];
		
		if(isset($_SESSION['Email']))
{
	$Email=$_SESSION['Email']; 

	$query="SELECT * FROM staffregister where Email='$Email'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 

 	while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$Name= $result['Name'];
			 	echo "Welcome $Name";
			 }
}
  
			 ?></h1>
		</div>
	</header>
									

</body>
</html>

<!-- 
<form>
	<table align="center" border="2">
					<tr>	<th><a href="userdata.php">User Data</a> </th>
							<th><a href="staffdata.php">Driver Data</a> </th>
					</tr>

					<tr>	<th><a href="history.php">Vew History</a></th>
							<th><a href="role.php">Role Registration</a></th>
					</tr>

					

	</table>
	<table align="center" border="2">
		<tr>	
				<th><a href="staffinformation.php">My Information</a></th>
				<th><a href="vehicle.php">Vehicle</a></th>
		</tr>

		<tr>	<th><a href="vehicle_view.php">Vehicle View</a></th>
				<th><a href="using_vehicle.php">Using Vehicle</a></th>
		</tr>
		<tr>	<th><a href="return_vehicle.php">Return Vehicle</a></th></tr>
	</table>
	</form>
 -->