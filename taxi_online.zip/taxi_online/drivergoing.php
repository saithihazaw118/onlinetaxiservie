<?php 

session_start();

	include 'connection.php';

	 

if(isset($_SESSION['Email']))
{
	$Email=$_SESSION['Email']; 

	$query="SELECT * FROM staffregister where Email='$Email'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 

 	while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$StaffID= $result['StaffID'];
			 	 $StaffID;
			 }
}
	
 		$show="SELECT p.Pick_up_address, p.Drop_off_address, p.Fees, u.FullName, u.PhoneNumber, p.RentID
 		FROM history h, userregister u, staffregister s, private_rent p
 		WHERE h.UserID=u.UserID
 		and h.StaffID=s.StaffID
 		and h.RentID=p.RentID
 		and s.StaffID='$StaffID'
 		and h.StaffID=h.StaffID";
 		$data=mysqli_query($connection,$show);
 		$total=mysqli_num_rows($data); 


 		if ($total !=0) 
 		{
 			?>

 				<table class="table" align="center" cellpadding="5px" style="color:black">
		<tr style="color:black">
 			<th>RentID</th>
 			<th>Pick up Address</th>
 			<th>Drop off Address</th>
 			<th>Fees</th>
 			<th>UserName</th>
 			<th>Phone Number</th>

 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr>
 						<td>".$result['RentID']."</td>
 						<td>".$result['Pick_up_address']."</td>
 						<td>".$result['Drop_off_address']."</td>
 						<td>".$result['Fees']."</td>
 						<td>".$result['FullName']."</td>
 						<td>".$result['PhoneNumber']."</td>
 						<td><a href='delete.php?RentID=".$result['RentID']."' > Logout </a> </td>
 				</tr> " ;
 		}
 	}

  ?> 

 
 

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="drivergoing.css">
	<title>Waiting Page</title>
</head>
<body> 
	<table class="table1" align="center">
		<tr>
			<th>

 <IMG SRC="driver.gif">

</th>
 </tr>
  
  <tr>
  	<th>Pleace Click Logout</th>
  </tr>

 </table>



</body>
</html>