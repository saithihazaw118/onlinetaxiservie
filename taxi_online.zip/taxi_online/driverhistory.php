	<?php 
	session_start();
	include 'connection.php';

 

$Email=$_SESSION['Email'];
 
 

 		$query="SELECT * FROM history h, staffregister s 
 		WHERE Email='$Email'
 		and h.StaffID=s.StaffID";
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 


 		if ($total !=0) 
 		{
 			?>

 				<table align="center" cellpadding="5px" style="color:white">
		<tr style="color:lime">
 			<th>RentID</th>
 			<th>Pick up Address</th>
 			<th>Drop off Address</th>
 			<th>Fees</th>
 			<th>UserID</th>
 			<th>Date</th>
 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr>
 						<td>".$result['RentID']."</td>
 						<td>".$result['Pick_up_address']."</td>
 						<td>".$result['Drop_off_address']."</td>
 						<td>".$result['Fees']."</td>
 						<td>".$result['UserID']."</td>
 						<td>".$result['Rent_Date']."</td>
 				</tr>  " ;
 		}
 	}

  ?> 



 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="driverhistory.css"> 
 	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title>User Data</title>  
 </head>
 <body>

 <form> 

 	<label class="div1"><a href="viewrent.php"><i class="fa fa-reply">Back</i></a></label> <br>

 </form>
 </body>


 </html> 
