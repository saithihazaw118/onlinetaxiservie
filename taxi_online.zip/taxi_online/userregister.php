<?php 
session_start();
include 'connection.php';



	if (isset($_POST['btnregister']))
	 {
	 	
		$FullName=$_POST['txtfullname'];
		$DOB=$_POST['txtdob'];
		$Password=$_POST['txtpassword'];
		$Email=$_POST['txtemail'];
		$Address=$_POST['txtaddress'];
		$Phonenumber=$_POST['txtphonenumber'];
		$Gender=$_POST['gender'];


		$CheckEmail="SELECT * FROM userregister WHERE Email='$Email'";
		$EmailResult=mysqli_query($connection,$CheckEmail);
		$count=mysqli_num_rows($EmailResult);

    if($count > 0)  
    {
    echo "<script>window.alert('Email Address $EmailAddress Exists')</script>";
    echo "<script>window.location='userregister.php'</script>";
    exit();
    } 
    	
    	$insert="INSERT INTO  userregister(FullName,Date_of_Birth,Password,Email,Address,PhoneNumber,Gender) 
    	values('$FullName','$DOB','$Password','$Email','$Address','$Phonenumber','$Gender')";

   	    $query=mysqli_query($connection,$insert);

    if ($query) {
      echo "<script>window.alert('User Registration Successful.')
      window.location='login.php'</script>";
    }
      else
       {
         mysqli_error($connection);
       }

          function ClearText()
         {
          txtfullname.Text =="";
          txtdob.Text=="";
          txtpassword.Text=="";
          txtemail.Text=="";
          txtaddress.Text=="";
          txtphonenumber.Text=="";
         
        }

       

  }

 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
	<link rel="stylesheet" type="text/css" href="style.css"> 
</head>
<body>
	<div class="header"><h2>User Register</h2></div>
	<form action="userregister.php" method="POST"> 

			

			<div class="input-group">
				<label>Full Name:</label>
				<input type="text" name="txtfullname" required>
			</div>

			<div class="input-group">
				<label>Date Of Birth:</label>
				<input type="date" name="txtdob" required>
			</div>

			<div class="input-group">
				<label>Password:</label>
				<input type="Password" name="txtpassword" required>
			</div>

			<div class="input-group">
				<label>Email Address:</label>
				<input type="Email" name="txtemail" placeholder="xxx@gmail.com" required>
			</div>

			<div class="input-group">
				<label>Address:</label>
				<textarea type="text" name="txtaddress"  required> </textarea>
			</div>
			
			<div class="input-group">
				<label>Phone Number:</label>
				<input type="text" name="txtphonenumber" placeholder="09..." required>
			</div>

			<div class="input-group">
				<label>Gender</label> </div> 
			<div>
				Male<input type="radio" name="gender" value="Male" required>   
				Female<input type="radio" name="gender" value="Female" required>  
			</div>
		
			<div class="input-group"> 
				<label><input type="submit" class="upd" name="btnregister" value="Register" ></label>
				<label><input type="reset" name="btncancel" class="upd" value="Cancel" onclick="ClearText();" >
       				 
       			</label> 
       			<h2 align="right"> <i><a href="login.php">Login Here </a></i></h2>
			</div>
		
		
	</form>
</body>
</html>


