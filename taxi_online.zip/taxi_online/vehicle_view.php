<?php 
	session_start();
	include 'connection.php';
 ?>

<!DOCTYPE html>
<html>
<head>
	<title>Vehicle View</title>
<link rel="stylesheet" type="text/css" href="vehicleview.css">
</head>
<body>
	<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
</header>
 <form>
 		<?php 
 	 $query="SELECT * FROM driver";
     $data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data);  
 		?>

 	<table border="1" class="first">
 		<tr>
 			<th>Name</th>
 			<th>Phone Number</th>	
 			<th>Choose</th>
 		</tr> 

 		<?php 	if ($total !=0  )
 				{    
 		?>

 		<?php 
 		 	while ($result=mysqli_fetch_assoc($data)) 
 		 		{
 		 	echo " 
 			<tr>
 				<td>".$result['Name']."</td>
 				<td>".$result['Phone_Number']."</td>
 				<td><a href='vehicleaccept.php?Name=$result[Name] &
 							StaffID=$result[StaffID] &
 							Email=$result[Email] &
 							Phone_Number=$result[Phone_Number] '>Click</a></td>	
 			</tr> "; } }
 		?>
 			
 	</table>

 	<?php 
 	 $vehicle="SELECT VehicleID, Type, Vehicle_License FROM vehicle";
     $vehicledata=mysqli_query($connection,$vehicle);
 	$vehicletotal=mysqli_num_rows($vehicledata);  
 		?>

 	<table border="1" align="center" class="second">
 		<tr>
 			<th>Type</th>
 			<th>Vehicle License</th>	
 			
 		</tr>

 		<?php 	if ($vehicletotal !=0  )
 				{   
 		?>

 		<?php 
 		 	while ($vehicleresult=mysqli_fetch_assoc($vehicledata)) 
 		 		{
 		 	echo " 
 			<tr>
 				<td>".$vehicleresult['Type']."</td>
 				<td>".$vehicleresult['Vehicle_License']."</td>
 					
 			</tr> "; } }
 		?>

 	</table>
 	

 </form>
</body>
</html>

