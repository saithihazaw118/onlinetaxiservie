	
<?php
session_start();
include 'connection.php';



	if (isset($_POST['btnregister']))
	 {
		$Staff=$_POST['txtstaffname'];
		$DOB=$_POST['txtdob'];
		$Password=$_POST['txtpassword']; 
		$Email=$_POST['txtemail'];
		$Address=$_POST['txtaddress'];
		$Phonenumber=$_POST['txtphonenumber'];
		$Gender=$_POST['gender']; 
		$RoleID=$_POST['RoleID'];


		$CheckEmail="SELECT * FROM staffregister WHERE Email='$Email'";
		$EmailResult=mysqli_query($connection,$CheckEmail);
		$count=mysqli_num_rows($EmailResult);

    if($count > 0) 
    {
    echo "<script>window.alert('Email Address $Email Exists')</script>";
    echo "<script>window.location='staff.php'</script>";
    exit();
    }
 
    	$insert="INSERT INTO staffregister(Name,Date_of_Birth,Password,Email,Address,Phone_Number,Gender,RoleID) 
    	values('$Staff','$DOB','$Password','$Email','$Address','$Phonenumber','$Gender','$RoleID')";

    	
    	 $query=mysqli_query($connection,$insert);
    	  

    if ($query) {
      echo "<script>window.alert('Almost Success.')</script>";

    }
      else
       {
         mysqli_error($connection);
       }
/////////////driver insert///////////////////////////////////////

	$query="SELECT Name,Email,Phone_Number,StaffID FROM staffregister
			WHERE RoleID='2'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 


while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$Name= $result['Name'];
			 	$Email= $result['Email'];
			 	$Phone_Number= $result['Phone_Number'];
			 	$StaffID= $result['StaffID'];
			 }

     $int="INSERT INTO driver(Name,Email,Phone_Number,StaffID) 
    values('$Name','$Email','$Phone_Number','$StaffID')";

    $qer=mysqli_query($connection,$int);
    	

        if ($qer) 
        {
      echo "<script>window.alert('Staff Registration Successful.')
       window.location='stafflogin.php'</script>";

    }
      else
       {
         mysqli_error($connection);
       }

      
/////////////////cancel button function/////////////////////
          function ClearText()
         {
          txtname.Text == "";
          txtdob.Text=="";
          txtpassword.Text=="";
          txtemail.Text=="";
          txtaddress.text=="";
          txtphone.Text=="";
          gender.Text=="";
          cborole.Text=="";
        }

       

  }

 ?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UFT-8">
	
	<title>Registration Form</title>
	<link rel="stylesheet" type="text/css" href="staffregister.css">
</head>
<body>
	<form action="staff.php" method="POST">

		<div class="wrapper">
			<div class="title">
					Registration Form
			</div>

			<div class="form">
			<div class="input_field">
				<label>Name:</label>
				<input type="text" name="txtstaffname"  class="input">
			</div>

			<div class="input_field">
				<label>Date Of Birth:</label>
				<input type="date" name="txtdob" required class="input">
			</div>

			<div class="input_field">
				<label>Password:</label>
				<input type="Password" name="txtpassword" required class="input" >
			</div>

			<div class="input_field">
				<label>Email Address:</label>
				<input type="Email" name="txtemail" placeholder="xxx@gmail.com" required class="input" >
			</div>

			<div class="input_field">
				<label>Address:</label>
				<textarea name="txtaddress" required class="textarea"></textarea>
			</div>

			<div class="input_field">
				<label>Phone Number:</label>
				<input type="text" name="txtphonenumber" required class="input" >
			</div>

			<div class="input_field">
				<label>Gender:</label>
				<div class="customer_select">
					<select name="gender" required>
					<option value="Male">Male</option>
					<option value="Female">Female</option>
					</select>
				</div>
			</div>


			<div class="input_field">
				<label>Select Role:</label>

				<label> 
				<select name="RoleID" required class="input">
					<option required="---Select Role---">---Select Role---</option>
					<?php 
						$select="SELECT * FROM role  ";
						$run=mysqli_query($connection,$select);
						$count=mysqli_num_rows($run);

						for($i=0;$i<$count;$i++)
						{
							$data=mysqli_fetch_array($run);
							$RoleID=$data['RoleID'];
							$Role_Type=$data['Role_Type'];

							echo "<option value='$RoleID'>".$Role_Type."</option>";
						}
						?>
					
				</select>
				</label>
			</div>

			<div class="input_field terms">
				<label class="check">
				<input type="checkbox">
				<span class="checkmark"></span>
				</label>
				<p color='blue'>Agreed to terms and conditions</p>
			</div>

		
			<div class="input_field">
				<input type="submit" name="btnregister" class="btn" value="Register">
				<input type="reset" name="btncancel" class="btn" value="Cancel" onclick="ClearText();" >      			
			</div>

			 <div>
			 	<a href="stafflogin.php"> <b style="color: green">Login </b></a> 
			 </div>

			</div>

		</div>
		
	
</body>

</html>