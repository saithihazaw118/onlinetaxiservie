<?php 
session_start();
include 'connection.php';

if (isset($_POST['btnregister'])) 
	{

	
    $type=$_POST['txttype'];
	$license=$_POST['txtlicense']; 

	$Checklicence="SELECT * FROM vehicle WHERE Vehicle_License='$license'";
		$licenceResult=mysqli_query($connection,$Checklicence);
		$count=mysqli_num_rows($licenceResult);

    if($count > 0)
    {
    echo "<script>window.alert('$license already Exists')</script>";
    echo "<script>window.location='vehicle.php'</script>";
    exit();
    }

	$insert="INSERT INTO  vehicle(Type,Vehicle_License) 
    	values('$type','$license')"; 

   	    $query=mysqli_query($connection,$insert); 

    if ($query) {
      echo "<script>window.alert('Vehicle Registration Successful.')
      window.location='vehicle_view.php'</script>";
    }
      else
       {
         mysqli_error($connection);
       }
  		function ClearText()
         {
          txttype.Text == "";
          my_image.file=="";
          txtlicense.Text=="";
         
        }
			
	}
 ?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="vehicle.css">
	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	<title><h1><b>Vehicle Registration</b></h1></title>
</head>
<body>	
 <header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</header>

	<form action="vehicle.php" method="POST" align="center"> 
	
	<div>
		<div align="center"><h2><b>Vehicle Registration Form</b></h2></div>
		<div>

			<div>
				<label>Type</label>
				<input type="text" name="txttype" class="type"  required>
			</div>

			
			<div>
				<label>Vehicle License</label>
				<input type="text" name="txtlicense" class="type"  required>
			</div>

			
			</div>

			<div>
				<input class="update" type="submit" name="btnregister" value="Register" class="btn"> 
				<input class="update" type="reset" name="btncancel" value="Cancel" onclick="ClearText();" > 
				<label class="div1"><a href="adminhome.php"><i class="fa fa-reply">	Back</i></a></label>
		       	
			</div>
			

		</div> 
	
	
			
		
</body>
</html>