<?php 

	session_start();
	include 'connection.php'; 
	
	$StaffID=$_GET['StaffID'];

	
 if($StaffID)
		{
	$StaffIDD=$_GET['StaffID']; 
	echo $StaffIDD;

	$sql="SELECT * FROM history where StaffID='$StaffIDD'";
	$his=mysqli_query($connection,$sql);
 	$total1=mysqli_num_rows($his); 	

 	while ($row=mysqli_fetch_assoc($his))
			 		{ 
			 	$RentID= $row['RentID'];
			 		}
		}
	

if ((['btnback']))
	 {

	
		$sql="DELETE FROM history WHERE StaffID='$StaffIDD' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script>alert('Now to back to Admin Home Page.') 
			window.location='adminhome.php'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);

	 }

 ?> 

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 <form>
 	<table>
 		<tr>
 			<td>	<input type="submit" name="btnback" value="Back To Home Page"></td>
 		</tr>
 	</table>
 </form>
 </body>
 </html>
