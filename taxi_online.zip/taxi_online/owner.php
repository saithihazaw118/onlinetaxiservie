<?php 
	include 'connection.php';
	session_start();

	if (isset($_POST['btnregister'])) {
		$Type=$_POST['txttype'];

		$checkRoleType="SELECT * FROM owner WHERE Type='$Type'";
		$Type_result=mysqli_query($connection,$checkRoleType);
		$count=mysqli_num_rows($Type_result);
		if($count > 0) 
		{
		echo "<script>window.alert('Type $Type Already Exist')</script>";
		echo "<script>window.location='owner.php'</script>";
		exit();
		}

		$insert="INSERT INTO  owner (Type) values('$Type')";

		$query=mysqli_query($connection,$insert);

		if ($query) {
			echo "<script>window.alert('Registration Successful')
			window.location='adminhome.php'</script>";   
		}
		  else
  		 {
   			 mysqli_error($connection);
   		 }
   		  	function ClearText()
			{
			txtroletype.Text == "";
			}
	}
	echo "<hr>";
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title>Owner Register Form</title>
 </head>
 <body>
 	<form action="owner.php" method="POSt">
 		<table cellpadding="2px" border="2px">
 			<tr>
 				<td>Owner ID</td>
 				<td><input type="ID" name="txtOwnerID" placeholder="*****" readonly></td>
 			</tr>
 			<tr>
 				<td>Type</td>
 				<td><input type="text" name="txttype" required></td>
 			</tr>
 		</table>
 				<input type="submit" name="btnregister" value="Register">
 				<input type="reset" name="btncancel" value="Cancel" onclick="ClearText();" >
 				<a href="adminhome.php">Back To Admin Home </a>
 	</form>
 </body>
 </html>