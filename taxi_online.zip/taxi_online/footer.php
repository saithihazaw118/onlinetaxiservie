	
<footer style="background-color: ivory;height: 15%">
			<div class="container_12">
				<div class="grid_12">
					<div class="f_phone"><span>Call Us:</span> + 1800 559 6580</div>
					<div class="socials">
						<a href="#" class="fa fa-twitter"></a>
						<a href="#" class="fa fa-facebook"></a>
						<a href="#" class="fa fa-google-plus"></a>
						<a href="#" class="fa fa-instagram"></a>
					</div>
					<div class="copy">
						<div class="st1">
						<div class="brand">Tour<span class="color1">T</span>axi </div>
						&copy; 2014	| <a href="#">Privacy Policy</a> </div> Website designed by <a href="http://www.templatemonster.com/" rel="nofollow">TemplateMonster.com</a>
					</div>
				</div>
				<div class="clear"></div>
			</div>
		</footer>

<style type="text/css">
	footer {
	display: block;
    padding: 0px 0 60px;
    font-size: 14px;
    color: #aaa;
    line-height: 18px;
    font-family: 'Roboto Condensed', sans-serif;
}

.copy {
    font-family: 'Open Sans', sans-serif;
}

.st1 {
    padding-top: 80px;
    color: #e2e2e2;
    margin-bottom: 8px;
}

.brand {
    position: relative;
    top: -7px;
    font: 30px/18px 'Roboto Condensed', sans-serif;
    display: inline-block;
    font-size: 30px;
}

.f_phone {
    padding-top: 72px;
    font-size: 40px;
    line-height: 36px;
    float: right;
    color: #e2e2e2;
}

.f_phone  span {
    position: relative;
    top: 4px;
    font-size: 30px;
}

.socials {
    margin-right: 96px;
    padding-top: 82px;
    float: right;
    overflow: hidden;
}

.socials a {
    display: block;
    float: left;
    margin: 0 6px 0 7px;
    color: #fff;
    text-align: center;
    background-color: #fdc903;
    border-radius: 500px;
    width: 58px;
    height: 58px;
    font-size: 24px;
    line-height: 58px;
}

.socials a:hover {
    color: #fdc903;
    background-color: #585757;
}

#toTop {
    display: none;
    text-decoration: none;
    position: fixed;
    bottom: 40px;
    left: 51%;
    margin-left: 610px;
    overflow: hidden;
    width: 61px;
    height: 75px;
    border: none;
    text-indent: -999px;
    z-index: 20;
    background: url(../images/totop.png) no-repeat left 0;
    transition: 0s ease;
    -o-transition: 0s ease;
    -webkit-transition: 0s ease;
}
#toTop:hover {
    outline: none;
    background-position: right 0;
}
</style>