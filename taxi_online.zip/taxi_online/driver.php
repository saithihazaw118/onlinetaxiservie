<?php 

session_start();
include 'connection.php';


$query="SELECT * FROM staffregister where RoleID='2' ";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 


		   if ($total !=0) 
 		{
 			?>

 				<table align="center" cellpadding="5px" border="5px" style="color:gray">
		<tr>
 			<th>Name</th>
 			<th>Date of Birth</th>
 			<th>Password</th>
 			<th>Email</th>
 			<th>Address</th>
 			<th>Phone Number</th>
 			<th>Gender</th>
 			<th>RoleID</th>
 			<th>StaffID</th>
 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr>
 						<td>".$result['Name']."</td>
 						<td>".$result['Date_of_Birth']."</td>
 						<td>".$result['Password']."</td>
 						<td>".$result['Email']."</td>
 						<td>".$result['Address']."</td>
 						<td>".$result['Phone_Number']."</td>
 						<td>".$result['Gender']."</td>
 						<td>".$result['RoleID']."</td>
 						<td>".$result['StaffID']."</td>
 						
 				</tr>  " ;
 		}

 	} 

 	


 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<title></title>
 </head>
 <body>
 	
 </body>
 </html>