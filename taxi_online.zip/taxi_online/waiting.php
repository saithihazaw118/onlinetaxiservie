<!DOCTYPE html>
<html>
<head>
	<title>Waiting Page</title>
</head>
<body> 
	<table align="center">
		<tr>
			<th>

 <IMG SRC="image1.gif">

</th>
 </tr>

 <tr><th style="color:blue" ><font size="+2" style="font-family: Courier">Please Waiting Your Driver</font></th></tr>
<tr><th><a href="login.php">Logout</a></th></tr>
 </table>



</body>
</html>

