 
 <?php 

	session_start();
	include 'connection.php';


	$VehicleID=$_GET['VehicleID'];
	$Type=$_GET['Type'];
	$Vehicle_License=$_GET['Vehicle_License'];
	




	$query="SELECT * FROM using_vehicle";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 

 	while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$StaffID= $result['StaffID'];
			 	$ID= $result['ID'];
			 	

			 }

 



	$update="UPDATE using_vehicle SET Type='$Type',
                                    Vehicle_License='$Vehicle_License',
                                    VehicleID='$VehicleID'
                                    WHERE StaffID='$StaffID'
                                    AND ID='$ID'";

			 if (mysqli_query($connection,$update)) 
			 {
			 	echo "<script>alert('Vehicle Selected.') </script>";
	 		} 
	 	else 
	 		{
		echo "Error: " . $update . "" . mysqli_error($connection);
	 		}

		
	 $sql="DELETE FROM vehicle WHERE VehicleID='$VehicleID' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script> window.location='using_vehicle.php'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);
		
 ?>
