<?php 

	session_start();

	include 'connection.php';
	 
	$StaffID=$_GET['StaffID'];


	$result = mysqli_query($connection, "SELECT SUM(Fees) AS sum_fees FROM history Where StaffID='$StaffID'"); 
	$row = mysqli_fetch_assoc($result); 
	$sum = $row['sum_fees'];
	

	$driver=$sum*0.15;
	

	$company=$sum*0.85;



 ?>
 
 <!DOCTYPE html>
 <html>
 <head>
 	 <link rel="stylesheet" type="text/css" href="return1.css">
 	<title></title>
 </head>
 <body>
 	<form action="return_vehicle1.php" method="POST">

 		<?php 
 	 $query="SELECT s.Name,h.Pick_up_address,h.Drop_off_address,h.Fees,h.StaffID,h.Rent_Date 
			FROM history h, staffregister s
			where h.StaffID='$StaffID'
			and s.StaffID=h.StaffID ";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data);  
 		?>

 	<table border="1" >
 		<tr>
 			<td>Driver Name</td>
 			<td align="center" colspan="2">Total Rent</td>	
 			<td>Fees</td>
 			<td>Staff ID</td>
 			<th>Rent Date</th>
 		</tr>

 		<?php 	if ($total !=0  )
 				{    
 		?>

 		<?php 
 		 	while ($result=mysqli_fetch_assoc($data)) 
 		 		{
 		 	echo " 
 			<tr>
 				<td>".$result['Name']."</td>
 				<td >".$result['Pick_up_address']."</td>
 				<td>".$result['Drop_off_address']."</td>
 				<td>".$result['Fees']."</td>
 				<td>".$result['StaffID']."</td>
 				<td>".$result['Rent_Date']."</td>
 			</tr>
 			 "; } }
 		?>
 			
 	</table>

 <table>
 	<tr>
 		<th>Total Fees</th>
 		<th><input type="text" name="txtfees" value="<?php echo $sum ?>"></th>
 	</tr>

 			<tr>
 				<th>For Company</th>
 				<th>For Driver</th>
 			</tr>
 			<tr>
 				<td><input type="text" name="txtcompany" value="<?php echo $company ?>"></td>
 				<td><input type="text" name="txtdriver" value="<?php echo $driver ?>"></td>
 			</tr>
 			
</table>
<table>
	<tr>
 	
	

<?php 
 		$sql="SELECT * FROM driver WHERE StaffID='$StaffID' ";
 		$for=mysqli_query($connection,$sql);
 		$total1=mysqli_num_rows($for); 

		if ($total1 !=0) 
				{	
		while ($result1=mysqli_fetch_assoc($for)) 
 		 		{
 		 				$StaffID= $result1['StaffID'];
 		 				echo $StaffID;
 		 		echo "
 			 <tr><td><a href='deletehistory.php?StaffID=".$StaffID."' > <h2>Back to Home Page</h2> </a> </td></tr>
 		 			";

 		 		}
 			 }
  ?> 

 	</tr>
</table>

 	</form>
 </body>
 </html>


 		


