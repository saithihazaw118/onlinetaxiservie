<?php 
  session_start();
  include 'connection.php';

   $_GET['UserID'];
  $_GET['FullName'];
  $_GET['Date_of_Birth'];
  $_GET['Password'];
  $_GET['Email'];
  $_GET['Address'];
  $_GET['PhoneNumber'];
   $_GET['Gender'];



  if(isset($_GET['btnUpdate']))
   {

    $userid=$_GET['UserID']; 
    $fullname=$_GET['FullName'];
    $dob=$_GET['Date_of_Birth'];
    $pass=$_GET['Password'];
    $email=$_GET['Email'];
    $address=$_GET['Address'];
    $phonenumber=$_GET['PhoneNumber'];
     $gender=$_GET['Gender'];

   $query= "UPDATE userregister SET UserID='$userid',
                                    FullName='$fullname',
                                    Date_of_Birth='$dob',
                                    Password='$pass',
                                    Email='$email',
                                    Address='$address',
                                    PhoneNumber='$phonenumber',
                                    Gender='$gender'
                                    WHERE UserID='$userid' ";

   $data=mysqli_query($connection,$query);

       if ($data)
       {
         echo "<script>window.alert('Update Successful')</script>";
        echo "<script>window.location='myinformation.php'</script>";
       }  

      else
      {
         echo "<font color='red'>Update Failed,Try Again </font> ";
      }
}   


 ?>

 <!DOCTYPE html>
 <html>
 <head>
  <link rel="stylesheet" type="text/css" href="style.css"> 
   <title>Update Form</title>
 </head>

 <body>
  <div class="header"><h2>User Update Form</h2></div>
    <form action="userupdateform.php" method="GET" enctype="multipart/form-data">
  
      <div class="input-group">
        <label>User ID</label>
        <input style="background-color:red" type="text" name="UserID" value="<?php echo $_GET['UserID']; ?>" readonly>
      </div>

       <div class="input-group">
        <label>Email</label>
        <input style="background-color:red" type="Email" name="Email" value="<?php echo $_GET['Email']; ?>"  >
      </div>

      <div class="input-group">
        <label>Full Name</label>
        <input type="text" name="FullName" value="<?php echo $_GET['FullName']; ?>" >
      </div>

      <div class="input-group">
        <label>Date Of Birth</label>
        <input type="text" name="Date_of_Birth" value="<?php echo $_GET['Date_of_Birth']; ?>" >
      </div>

      <div class="input-group">
        <label>Password</label>
        <input type="Password" name="Password" value="<?php echo $_GET['Password']; ?>" >
      </div>

     

      <div class="input-group">
        <label>Address</label>
        <input type="text" name="Address" value="<?php echo $_GET['Address']; ?>"  >
      </div>
      
      <div class="input-group">
        <label>Phone Number</label>
        <input type="text" name="PhoneNumber" value="<?php echo $_GET['PhoneNumber']; ?>" >
      </div>

       <div class="input-group">
           <label>Gender:</label>
           <div class="customer_select">
          <select name="Gender">
           <option value="Male"  
          <?php 
            if ( $_GET['Gender'] == "Male") 
            {
              echo "checked";
            }
           ?>
          >Male</option>
          <option value="Female" <?php 
            if ($_GET['Gender'] == "Female") 
            {
              echo "checked";
            }
           ?>
           >Female</option>
          </select>
        </div>
      </div>
    
      <div class="input-group"> 
        <label><input type="submit" class="upd" name="btnUpdate" value="Update" ></label>
        <label><input type="reset" name="btncancel" class="upd" value="Cancel" onclick="ClearText();" >
               
            </label> 
            <h2 align="right"> <i><a href="myinformation.php">Back </a></i></h2>
      </div>
    
  </form>
 
 </body>