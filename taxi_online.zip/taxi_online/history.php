	<?php 
	session_start();
	include 'connection.php';



 		$query="SELECT * FROM history";
 		
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data);  

// $userid=$result['UserID'];

// if(isset($result['UserID']))
// {
// 	$userid=$result['UserID']; 

// 	$query="SELECT FullName FROM userregister where UserID='$userid'";
// 	$data=mysqli_query($connection,$query);
//  	$total=mysqli_num_rows($data); 

//  	while ($result1=mysqli_fetch_assoc($data))
// 			 { 
// 			 	$FullName= $result1['FullName'];
// 			 	echo $FullName;
// 			 }
// }

  


 		if ($total !=0) 
 		{
 			?>

 				<table align="center" cellpadding="5px" style="color:white"> 
		<tr  style="color:lime"> 
 			<th>RentID</th>
 			<th>Pick up Address</th>
 			<th>Drop off Address</th>
 			<th>Fees</th>
 			<th>User ID</th>
 			<th>Driver ID</th>
 			<th>Rent Date</th>
 			<th>Operation</th>
 			
 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {



 			echo " 
 			<tr>
 						<td>".$result['RentID']."</td>
 						<td>".$result['Pick_up_address']."</td>
 						<td>".$result['Drop_off_address']."</td>
 						<td>".$result['Fees']."</td>
 						<td>".$result['UserID']."</td>
 						<td>".$result['StaffID']."</td>
 						<td>".$result['Rent_Date']."</td>
 						<td><a href='admindelete.php?RentID=".$result['RentID']."' > Delete </a> 
 				</tr>  " ;
 		}
 	}

  ?> 



 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="history.css">
 	<title>User Data</title>
 </head>
 <body>
<header>
 	<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
		
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
	</header>
 <form> 
 	
 </form>
 </body>
 </html> 