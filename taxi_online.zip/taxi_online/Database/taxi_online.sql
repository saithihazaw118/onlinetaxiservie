-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8111
-- Generation Time: Nov 28, 2021 at 03:41 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `taxi_online`
--

-- --------------------------------------------------------

--
-- Table structure for table `driver`
--

CREATE TABLE `driver` (
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Phone_Number` varchar(20) NOT NULL,
  `StaffID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `driver`
--

INSERT INTO `driver` (`Name`, `Email`, `Phone_Number`, `StaffID`) VALUES
('Joe Mar', 'joe@gmail.com', '0967584937', 66),
('Ar Ar    ', 'ar@gmail.com    ', '0947368935', 13),
('Aung Aung', 'aye1@gamil.com ', '0967876787', 16),
('Yu Wati Lin            ', 'yu@gmail.com            ', '09789147027', 56),
('ri ri  ', 'ri@gmail.com  ', '0998098787', 9),
('Kyaw Myo', 'kyaw@gmail.com', '0923768946', 69),
('Myo Gyi  ', 'gyi@gmail.com  ', '0947898439', 70);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `ID` int(11) NOT NULL,
  `RentID` int(11) NOT NULL,
  `Pick_up_address` varchar(30) NOT NULL,
  `Drop_off_address` varchar(30) NOT NULL,
  `Fees` varchar(30) NOT NULL,
  `UserID` int(11) NOT NULL,
  `StaffID` int(11) NOT NULL,
  `Rent_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`ID`, `RentID`, `Pick_up_address`, `Drop_off_address`, `Fees`, `UserID`, `StaffID`, `Rent_Date`) VALUES
(38, 30, ' Yangon', 'Mandalay', '30000', 6, 16, '2021-09-17 16:12:04'),
(53, 37, ' Yaegu', 'Parami', '5000', 7, 16, '2021-09-30 15:25:07'),
(60, 43, 'Wai zanyantar city mart ', 'North dagon City mart', '6000', 5, 16, '2021-10-04 06:15:32'),
(61, 51, 'Yangon  ', 'Nay pyi taw', '7000', 5, 17, '2021-11-03 13:41:50'),
(62, 52, 'North Oakkalarpa 3 street ', 'Shwe Dagon Pogoda', '5000', 7, 17, '2021-11-03 14:08:44'),
(63, 53, ' Hledan Center', 'Way Zanyantar City mark', '4000', 5, 17, '2021-11-03 14:14:12'),
(64, 56, 'South oakkalar pa 7qtr 5st ', 'South Dagon 4tr 6st ', '5000', 5, 16, '2021-11-06 04:14:25'),
(65, 54, 'south oakkalar 3qtr 13st ', 'north oakkalar 4qtr 2st', '3500', 5, 17, '2021-11-26 16:03:03');

-- --------------------------------------------------------

--
-- Table structure for table `private_rent`
--

CREATE TABLE `private_rent` (
  `RentID` int(11) NOT NULL,
  `UserID` int(11) DEFAULT NULL,
  `FullName` varchar(30) NOT NULL,
  `Pick_up_address` varchar(30) DEFAULT NULL,
  `Drop_off_address` varchar(30) DEFAULT NULL,
  `Fees` varchar(30) DEFAULT NULL,
  `Date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `private_rent`
--

INSERT INTO `private_rent` (`RentID`, `UserID`, `FullName`, `Pick_up_address`, `Drop_off_address`, `Fees`, `Date`) VALUES
(61, 7, 'Ei Thandar  ', 'Seafood City Hot Pot ', 'Lotte Hotel', '4000', '2021-11-27 16:50:34'),
(65, 6, 'Hla Hla Hla', 'Yangon International Airpot ', 'Hotel Bo Bo Min', '5000', '2021-11-27 16:55:37');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `RoleID` int(11) NOT NULL,
  `Role_Type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`RoleID`, `Role_Type`) VALUES
(1, 'Admin'),
(2, 'Driver');

-- --------------------------------------------------------

--
-- Table structure for table `staffregister`
--

CREATE TABLE `staffregister` (
  `Name` varchar(30) NOT NULL,
  `Date_of_Birth` varchar(30) NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `Phone_Number` varchar(20) NOT NULL,
  `Gender` varchar(20) NOT NULL,
  `RoleID` int(11) NOT NULL,
  `StaffID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staffregister`
--

INSERT INTO `staffregister` (`Name`, `Date_of_Birth`, `Password`, `Email`, `Address`, `Phone_Number`, `Gender`, `RoleID`, `StaffID`) VALUES
('Aye Mya Mon', '1989-09-14                  ', '111  ', 'aung@gmail.com', 'North Oakkalar Road and Yandan', '0943565435', 'Female', 1, 14),
('Aye Mya Mon ', '1998-06-23 ', '777 ', 'aye123@gmail.com', 'Yazar Thingyan 1st, 11Qtr, Nor', '0987987067 ', 'Male', 1, 15),
('Hill Hill', '2021-09-17', '666', 'hill@gmail.com', 'mandalay', '09876543453', 'Female', 1, 55),
('Kyaw Myo', '1993-01-08', '222', 'kyaw@gmail.com', 'Hlain 4Qtr, 4st', '0923768946', 'Male', 2, 69),
('Myo Gyi', '1995-10-03', '222', 'gyi@gmail.com', 'Hledan 7Qtr, 12st', '0947898439', 'Male', 2, 70),
('Min Min', '1996-10-13', '222', 'min@gmail.com', 'North Oakkalar Pa 9Qtr 8st', '0978765643', 'Male', 2, 71),
('Myat Aung', '1995-05-15', '111', 'myat@gmail.com', 'Hledan 1Qtr 2st', '0965467895', 'Male', 2, 72),
('Thu Ta', '1997-06-11', '1212', 'thu@gmail.com', 'Kabar Aye 5Qtr 6st', '0945847387', 'Male', 2, 73);

-- --------------------------------------------------------

--
-- Table structure for table `userregister`
--

CREATE TABLE `userregister` (
  `UserID` int(11) NOT NULL,
  `FullName` varchar(30) NOT NULL,
  `Date_of_Birth` date NOT NULL,
  `Password` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Address` varchar(30) NOT NULL,
  `PhoneNumber` varchar(20) NOT NULL,
  `Gender` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userregister`
--

INSERT INTO `userregister` (`UserID`, `FullName`, `Date_of_Birth`, `Password`, `Email`, `Address`, `PhoneNumber`, `Gender`) VALUES
(5, 'Aung Min Min  ', '2002-03-05', '555  ', 'aung@gmail.com', ' Ani Gar St, 3st, South Oakkal', '0911111111', 'Male'),
(6, 'Hla Hla Hla', '2000-09-11', '333  ', 'hla@gmail.com', ' Waizanya Tar st, 3st, South O', '0945434567     ', 'Male'),
(7, 'Ei Thandar  ', '2004-06-16', '666  ', 'ei@gmail.com', ' Ma lar Myine St, North Oakkal', '0987861786  ', 'Female'),
(8, 'Thandar Ei Ei', '2001-02-17', '666', 'thandar@gmail.com', ' Aung Zay Ya Rd, 3Qtr, 13st, H', '0999978698', 'Female'),
(9, 'Aung Thein Min', '1999-04-08', '666', 'aung45@gmail.com', ' Moe Kaung Rd, 9st, Insein, Ya', '0988786656', 'Male'),
(10, 'John Joh', '1996-07-20', '123', 'joh@gmail.com', '4th St, Tarmwe, Yangon ', '0968765768', 'Male');

-- --------------------------------------------------------

--
-- Table structure for table `using_vehicle`
--

CREATE TABLE `using_vehicle` (
  `ID` int(11) NOT NULL,
  `StaffID` int(11) NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `Name` varchar(30) NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Phone_Number` varchar(20) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Vehicle_License` varchar(30) NOT NULL,
  `Using_Date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `using_vehicle`
--

INSERT INTO `using_vehicle` (`ID`, `StaffID`, `VehicleID`, `Name`, `Email`, `Phone_Number`, `Type`, `Vehicle_License`, `Using_Date`) VALUES
(70, 54, 36, 'killer bee    ', 'bee@gmail.com    ', '0989876756', 'Probox              ', '4G-7945', '2021-10-03 14:36:15'),
(72, 73, 41, 'Thu Ta ', 'thu@gmail.com ', '0945847387', 'Probox  ', '5E-4548', '2021-11-27 10:12:55'),
(74, 71, 44, 'Min Min ', 'min@gmail.com ', '0978765643', 'Probox ', '4A-5689', '2021-11-27 10:13:32'),
(75, 72, 42, 'Myat Aung ', 'myat@gmail.com ', '0965467895', 'Probox ', '4G-5687', '2021-11-27 10:19:04');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `VehicleID` int(11) NOT NULL,
  `Type` varchar(20) NOT NULL,
  `Vehicle_License` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`VehicleID`, `Type`, `Vehicle_License`) VALUES
(37, 'Probox      ', '4A-4023'),
(43, 'Probox ', '4E-3432'),
(45, 'Probox', '6G-5459');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `private_rent`
--
ALTER TABLE `private_rent`
  ADD PRIMARY KEY (`RentID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`RoleID`);

--
-- Indexes for table `staffregister`
--
ALTER TABLE `staffregister`
  ADD PRIMARY KEY (`StaffID`),
  ADD KEY `RoleID` (`RoleID`);

--
-- Indexes for table `userregister`
--
ALTER TABLE `userregister`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `using_vehicle`
--
ALTER TABLE `using_vehicle`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`VehicleID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `private_rent`
--
ALTER TABLE `private_rent`
  MODIFY `RentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `RoleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staffregister`
--
ALTER TABLE `staffregister`
  MODIFY `StaffID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=74;

--
-- AUTO_INCREMENT for table `userregister`
--
ALTER TABLE `userregister`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `using_vehicle`
--
ALTER TABLE `using_vehicle`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `VehicleID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `private_rent`
--
ALTER TABLE `private_rent`
  ADD CONSTRAINT `private_rent_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `userregister` (`UserID`);

--
-- Constraints for table `staffregister`
--
ALTER TABLE `staffregister`
  ADD CONSTRAINT `staffregister_ibfk_1` FOREIGN KEY (`RoleID`) REFERENCES `role` (`RoleID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
