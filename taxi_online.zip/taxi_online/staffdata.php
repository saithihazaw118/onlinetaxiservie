	<?php 
	session_start();
	include 'connection.php';
	$RoleID=$_SESSION['RoleID'];


 		$query="SELECT * FROM staffregister WHERE RoleID='2' ";
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 

 	   
 		if ($total !=0) 
 		{
 			?>

 				<table align="center" cellpadding="5px"  style="color:white">
				<tr style="color:lime">
				<th>StaffID</th>	
 				<th>Name</th>
 				<th>Date of Birth</th>
 				<th>Password</th>
 				<th>Email</th>
 				<th>Address</th>
 				<th>Phone Number</th>
 				<th>Role ID</th>
 				<th>Staff ID</th>
 				<th>Operation</th>
 				<th>Delete Account</th>
 				 
 				</tr>

 				<?php 
			while ($result=mysqli_fetch_assoc($data)){
 			echo " 
 			<tr>
 						<td>".$result['StaffID']."</td>
 						<td>".$result['Name']."</td>
 						<td>".$result['Date_of_Birth']."</td>
 						<td>".$result['Password']."</td>
 						<td>".$result['Email']."</td>
 						<td>".$result['Address']."</td>
 						<td>".$result['Phone_Number']."</td>
 						<td>".$result['RoleID']."</td>
 						<td>".$result['StaffID']."</td>
 						<td><a href='staffupdate.php?StaffID=$result[StaffID] &
 							Name=$result[Name] &
 							Date_of_Birth=$result[Date_of_Birth] &
 							Password=$result[Password] &
 							Email=$result[Email] &
 							Address=$result[Address] &
 							Phone_Number=$result[Phone_Number] &
 							Gender=$result[Gender] '>Edit</a> </td>

 						<td>	<a href='staffdelete.php?StaffID=$result[StaffID] '>Delete</a></td>
 						
 				</tr>  " ;
 		}
 	}

  ?> 


 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="userdata.css">
 	 <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title>User Data</title>
 </head>
 <body>
<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
	</header>

 </body> 
 </html> 