<?php 

session_start();

	include 'connection.php';
	
	$RentID=$_GET['RentID'];
 		$sql="DELETE FROM private_rent WHERE RentID='$RentID' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script>
			window.location='stafflogin.php'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);

 ?> 
