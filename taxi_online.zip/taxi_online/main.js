const input = document.querySelectorAll('.input');

function focusFunc(){
	let parent = this.parentNode.parentNode;
	parent.ClassList.add('focus');
}

function blurFunc(){
	let parent = this.parentNode.parentNode;
	if(this.value == "") {
	parent.ClassList.remove('focus');
	}
	
}

inputs.forEach(input  => {
	input.addEventListener('focus',focusFunc)
	input.addEventListener('blur',blurFunc);
})