<?php 
	$servername="localhost:8111";
	$username="root";
	$password="";
	$database="taxi_online";

	$connection=mysqli_connect($servername,$username,$password,$database);

	if(!$connection) {
		die("Connecting Failed:".mysqli_connect_error());
	}
	else
	{
		//echo "Connection Successful";
	}

	

 ?>
