<?php 

session_start();
include 'connection.php';

$UserID=$_SESSION['UserID'];
$FullName=$_SESSION['FullName'];
$dob=$_SESSION['Date_of_Birth'];
$pass=$_SESSION['Password'];
$email=$_SESSION['Email'];
$address=$_SESSION['Address'];
$phonenumber=$_SESSION['PhoneNumber'];
$gender=$_SESSION['Gender'];


?>	

<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="stylesheet" type="text/css" href="head.css">
		<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

		<title>Home</title>
		<meta charset="utf-8">
		<meta name = "format-detection" content = "telephone=no" />
		<link rel="icon" href="images/favicon.ico">
		<link rel="shortcut icon" href="images/favicon.ico" />
		<link rel="stylesheet" href="booking/css/booking.css">
		<link rel="stylesheet" href="css/camera.css">
		<link rel="stylesheet" href="css/owl.carousel.css">
		<link rel="stylesheet" href="css/style.css">
		<script src="js/jquery.js"></script>
		<script src="js/jquery-migrate-1.2.1.js"></script>
		<script src="js/script.js"></script>
		<script src="js/superfish.js"></script>
		<script src="js/jquery.ui.totop.js"></script>
		<script src="js/jquery.equalheights.js"></script>
		<script src="js/jquery.mobilemenu.js"></script>
		<script src="js/jquery.easing.1.3.js"></script>
		<script src="js/owl.carousel.js"></script>
		<script src="js/camera.js"></script>
		<!--[if (gt IE 9)|!(IE)]><!-->
		<script src="js/jquery.mobile.customized.min.js"></script>
		<!--<![endif]-->
		<script src="booking/js/booking.js"></script>
		<script>
			$(document).ready(function(){
				jQuery('#camera_wrap').camera({
					loader: false,
					pagination: false ,
					minHeight: '444',
					thumbnails: false,
					height: '28.28125%',
					caption: true,
					navigation: true,
					fx: 'mosaic'
				});
				$().UItoTop({ easingType: 'easeOutQuart' });
			});
		</script>
		
	</head>
	<body class="page1" id="top">
		<div class="main">
<!--==============================header=================================-->
			<header>  
				<div class="menu_block ">
					<div class="container_12">
						<div class="grid_12">
							<nav class="horizontal-nav full-width horizontalNav-notprocessed">
								<ul class="sf-menu">
									<li class="current"><a href="privaterent.php"><i class="fa fa-taxi"> Rent</i></a></li>
									<li><a href="myinformation.php"><i class="fa fa-user"> My Information </i></a></li>
									<li><a href="userhistory.php"><i class="fa fa-history">View History</i></a></li>
									<li><a href="login.php"><i class="fa fa-sign-out"> Logout</i></a></li>
									
									
								</ul>
							</nav>
							<div class="clear"></div>
						</div>
						<div class="clear"></div>
					</div>
				</div>
				<div class="container_12">
					<div class="grid_12">
						<h1>
							<a href="index.html">
								<img src="images/onlinetaxi1.jpg" alt="Your Happy Family">
							</a>
						</h1>
					</div>
				</div>
				<div class="clear"></div>
			</header>
			<div class="slider_wrapper ">
				<div id="camera_wrap" class="">
					<div data-src="images/slide.jpg" ></div>
					<div data-src="images/slide1.jpg" ></div>
					<div data-src="images/slide2.jpg"></div>
				</div>
			</div>
			<div class="container_12">
				<div class="grid_4">
					<div class="banner">
						<div class="maxheight">
							<div class="banner_title">
								<img src="images/icon1.png" alt="">
								<div class="extra_wrapper">Fast&amp;
									<div class="color1">Safe</div>
								</div>
							</div>
							There is no need to ride with the other people in the taxi that can be found in current taxi drivers. This is bacause our taxi drivers only deliver to the customers they hire. Taxi Drivers are our Company Staff, so our online taxi is safer that regular taxis.
							<a href="#" class="fa fa-share-square"></a>
						</div>
					</div>
				</div>
				<div class="grid_4">
					<div class="banner">
						<div class="maxheight">
							<div class="banner_title">
								<img src="images/icon2.png" alt="">
								<div class="extra_wrapper">Best
									<div class="color1">Prices</div>
								</div>
							</div>
							What makes our online taxi different from other taxi is that you do not have to check the price for money. Customers can go to the destination at any price.
							<a href="#" class="fa fa-share-square"></a>
						</div>
					</div>
				</div>
				<div class="grid_4">
					<div class="banner">
						<div class="maxheight">
							<div class="banner_title">
								<img src="images/icon3.png" alt="">
								<div class="extra_wrapper">Package
									<div class="color1">Delivery</div>
								</div>
							</div>
							Our customer forgot the package from our online taxi service company, but we waited for them at the companies or at the places where the passengers landed.
							<a href="#" class="fa fa-share-square"></a>
						</div>
					</div>
				</div>
				<div class="clear"></div>
			</div>
			
<!--==============================Content=================================-->
			<!-- <footer>
	
   <div class="middle">
 		
 	<a class="btn" href="#">
 		<i class="fa fa-facebook-official"></i>
 	</a>
 	<a class="btn" href="#">
 		<i class="fa fa-twitter-square"></i>
 	</a>
 	<a class="btn" href="#">
 		<i class="fa fa-google"></i>
 	</a>
 	<a class="btn" href="#">
 		<i class="fa fa-instagram"></i>
 	</a>
 	
	</div>
 </footer> -->

 <?php 
 	include 'footer.php';
  ?>