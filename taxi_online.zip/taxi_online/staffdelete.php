
<?php 

session_start();

	include 'connection.php';
	
	$StaffID=$_GET['StaffID'];
 		$sql="DELETE FROM staffregister WHERE StaffID='$StaffID' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script>alert('Delete Successful.') 
			window.location='staffdata.php'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);

 ?>