<?php 

session_start();

	include 'connection.php';
	
	$RentID=$_GET['RentID'];
 		$sql="DELETE FROM history WHERE RentID='$RentID' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script>alert('Delete Successful.') 
			window.location='history.php'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);

 ?> 
