<?php 
	session_start();
	include 'connection.php';



 		$query="SELECT * FROM using_vehicle";
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 

 	 
 		if ($total !=0) 
 		{
 			?>

 				<table align="center" cellpadding="5px" style="color:white">
		<tr style="color:lime">
 			<th>ID</th>
 			<th>Staff ID</th>
 			<th>Vehicle ID</th>
 			<th>Name</th> 
 			<th>Email</th>
 			<th>Phone Number</th>
 			<th>Type</th>
 			<th>Vehicle Licencse</th>
 			<th>Start Using Date</th>
 		</tr>
 
 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr>
 						<td>".$result['ID']."</td>
 						<td>".$result['StaffID']."</td>
 						<td>".$result['VehicleID']."</td>
 						<td>".$result['Name']."</td>
 						<td>".$result['Email']."</td>
 						<td>".$result['Phone_Number']."</td>
 						<td>".$result['Type']."</td>
 						<td>".$result['Vehicle_License']."</td>
 						<td>".$result['Using_Date']."</td>
 				</tr>  " ;
 		}
 	}

  ?> 



 <!DOCTYPE html>
 <html>
 <head>
 	<meta name="using_vehicle.php" content="width=device-width, initial-scale=1">
 	<link rel="stylesheet" type="text/css" href="userdata.css">
 	<title>User Data</title>
 </head>
 <body>

 <form> 
<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
	</header>
 	
 

 </form>
 </body>
 </html> 