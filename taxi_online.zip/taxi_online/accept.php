<?php


session_start();

	include 'connection.php';
	 
	$RentID=$_GET['RentID'];

	$query="SELECT * FROM private_rent where RentID='$RentID' ";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 


while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$RentID= $result['RentID'];
			 	$pick= $result['Pick_up_address'];
			 	$drop= $result['Drop_off_address'];
			 	$UserID= $result['UserID'];
			 	$Fees=$result['Fees'];
			 }



if(isset($_SESSION['Email']))
{
	$Email=$_SESSION['Email']; 

	$query="SELECT * FROM staffregister where Email='$Email'";
	$data=mysqli_query($connection,$query);
 	$total=mysqli_num_rows($data); 

 	while ($result=mysqli_fetch_assoc($data))
			 { 
			 	$StaffID= $result['StaffID'];
			 }
}
  



    	$insert="INSERT INTO  history(RentID,Pick_up_address,Drop_off_address,Fees,UserID,StaffID) 
    	values('$RentID','$pick','$drop','$Fees','$UserID','$StaffID')";

		 if (mysqli_query($connection,$insert)) 
			 {
		 echo "<script>alert('You accepted customer rent. Safe Your Driving.') 
			window.location='drivergoing.php'</script>";
	 		} 
	 	else 
	 		{
		echo "Error: " . $insert . "" . mysqli_error($connection);
	 		}
		

 	// 	$sql="DELETE FROM private_rent WHERE RentID='$RentID' ";
 	// 	if (mysqli_query($connection, $sql)) 
 	// 	{
		//     echo "<script>alert('We finding driver for driving to your place. Thank You.') 
		// 	window.location='drivergoing.php'</script>";
		// } 
		// else 
		// {
		//     echo "Error deleting record: " . mysqli_error($connection);
		// }
		// mysqli_close($connection);


	

?>
