	<?php 
	session_start();
	include 'connection.php';

$_SESSION['UserID'];
 
$_SESSION['FullName'];


 		$query="SELECT *,Name FROM history h, staffregister s 
 		where UserID='$_SESSION[UserID]'
 		and h.StaffID=s.StaffID";
 		
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 


 		if ($total !=0) 
 		{
 			?>

 				<table align="center" cellpadding="5px"  style="color:white">
		<tr style="color:lime">
 			<th>RentID</th>
 			<th>Pick up Address</th>
 			<th>Drop off Address</th>
 			<th>Fees</th>
 			<th>User Name</th>
 			<th>Driver Name</th>
 			<th>Date</th>
 		</tr>

 		<?php 

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			echo " 
 			<tr>
 						<td>".$result['RentID']."</td>
 						<td>".$result['Pick_up_address']."</td>
 						<td>".$result['Drop_off_address']."</td>
 						<td>".$result['Fees']."</td>
 						<td>".$_SESSION['FullName']."</td>
 						<td>".$result['Name']."</td>
 						<td>".$result['Rent_Date']."</td>
 				</tr>  " ;
 		}
 			
	}

  ?> 



 <!DOCTYPE html>
 <html>
 <head>
 	 <link rel="stylesheet" type="text/css" href="userhistory.css">
 	 <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title>User Data</title>
 </head>
 <body>

 <form> 

 	
 	<label class="upd"><a href="header.php"><i class="fa fa-reply">Back</i></a></label> 

 	<footer>
	
   <div class="middle">
 		
 	<!-- <a class="btn" href="https://www.facebook.com/">
 		<i class="fa fa-facebook-official"></i>
 	</a>
 	<a class="btn" href="https://www.facebook.com/">
 		<i class="fa fa-twitter-square"></i>
 	</a>
 	<a class="btn" href="https://www.google.com/">
 		<i class="fa fa-google"></i>
 	</a>
 	<a class="btn" href="https://www.instagram.com/">
 		<i class="fa fa-instagram"></i>
 	</a>
 -->

 
 	
	</div>
 </footer>


	
 </form>


 </body>

 </html> 
 	
