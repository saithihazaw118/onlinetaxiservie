<?php 
session_start();
include 'connection.php';

if (isset($_POST['btnclick']))
	 {
	 	$license=$_POST['txtlicense'];


		$check="SELECT * FROM using_vehicle WHERE Vehicle_License='$license'";
		$vehicleresult=mysqli_query($connection,$check);
		$count=mysqli_num_rows($vehicleresult);
		

	 if($count > 1) 
   		 {
    		echo "<script>window.alert('Vehicle License $license already Exists')</script>";
   			echo "<script>window.location='return_vehicle.php'</script>";
    		exit();
    	}


    	if ($count !=0) 
    	{

 	while ($result=mysqli_fetch_assoc($vehicleresult))
			 {

 			$StaffID=$result['StaffID'];
 			$VehicleID=$result['VehicleID'];
 			$Name=$result['Name'];
 			$Email=$result['Email'];
 			$Phone_Number=$result['Phone_Number'];
 			$Type=$result['Type'];
 			$Vehicle_License=$result['Vehicle_License'];

 			}
 
		$insert="INSERT INTO  driver(Name,Email,Phone_Number,StaffID) 
    	values('$Name','$Email','$Phone_Number','$StaffID')";
    	
    	$insert1="INSERT INTO  vehicle(VehicleID,Type,Vehicle_License) 
    	values('$VehicleID','$Type','$Vehicle_License')";

   	    $query=mysqli_query($connection,$insert);

   	     $query1=mysqli_query($connection,$insert1);

   	  

       	$sql="DELETE FROM using_vehicle WHERE Vehicle_License='$license' ";
 		if (mysqli_query($connection, $sql)) 
 		{
		    echo "<script>alert('Successful.') 
			window.location='return_vehicle1.php?StaffID=".$StaffID."'</script>";
		} 
		else 
		{
		    echo "Error deleting record: " . mysqli_error($connection);
		}
		mysqli_close($connection);

	 }
 }
 ?>

 <!DOCTYPE html> 
 <html>
 <head>
  <link rel="stylesheet" type="text/css" href="return.css"> 
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> 
 	<title> Return Vehicle</title>
 </head>
 <body>
 	<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
	</header>
 	<form action="return_vehicle.php" method="POST">
 		<table align="center">
 			<tr>
 				<td>Vehicle License</td>
 				<td><input type="text" required name="txtlicense"></td>
 			</tr>
 			<tr>
 				<th class="update"><input type="submit" name="btnclick" value="Click" ></th> <br>	
       			<th class="div1"><a href="adminhome.php"><i class="fa fa-reply">Back</i></a></th>
 			</tr>

 		</table>
 	</form>
 </body>
 </html>