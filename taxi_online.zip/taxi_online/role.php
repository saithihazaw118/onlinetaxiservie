<?php 
	include 'connection.php';
	session_start();

	if (isset($_POST['btnregister'])) {
		$Role_Type=$_POST['txtroletype'];

		$checkRoleType="SELECT * FROM role WHERE Role_Type='$Role_Type'";
		$RoleType_result=mysqli_query($connection,$checkRoleType);
		$count=mysqli_num_rows($RoleType_result);
		if($count > 0) 
		{
		echo "<script>window.alert('Role Type $Role_Type Already Exist')</script>";
		echo "<script>window.location='role.php'</script>";
		exit();
		}

		$insert="INSERT INTO  role (Role_Type) values('$Role_Type')";

		$query=mysqli_query($connection,$insert);

		if ($query) {
			echo "<script>window.alert('Staff Role Registration Successful')
			window.location='role.php'</script>";   
		}
		  else 
  		 {
   			 mysqli_error($connection);
   		 } 
   		  	function ClearText()
			{
			txtroletype.Text == "";
			}
	}
	echo "<hr>";
 ?>

 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="role.css">
 	<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 	<title>Role Register Form</title>
 </head>
 <body>
 	<header>
		<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				
				<li><a href="staffinformation.php">My Information</a></li>
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
	</header>

 	<form action="role.php" method="POSt"> 
 		
 		<table cellpadding="2px">
 			<tr>
 				<td>Role ID</td>
 				<td><input type="ID" name="txtRoleID" placeholder="*****" readonly></td>
 			</tr>
 			<tr>
 				<td>Role Type</td>
 				<td><input type="text" name="txtroletype" required></td>
 			</tr>
 			<tr>
 				<td colspan="2">	
 				<input class="update" type="submit" name="btnregister" value="Register">
 				<input class="update" type="reset" name="btncancel" value="Cancel" onclick="ClearText();" >
 				<h2><b class="upd"><a href="adminhome.php"><i class="fa fa-reply">Back </i></a></b></h2>
 				</td>
 			</tr>
 		</table>
 				
 				
 	</form>
 </body>
 </html>