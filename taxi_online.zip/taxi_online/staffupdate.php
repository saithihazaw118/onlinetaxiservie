<?php 
  session_start();
  include 'connection.php';

  $staffid=$_GET['StaffID'];
  
   $_GET['Name'];
  $_GET['Date_of_Birth'];
  $_GET['Password'];
  $_GET['Email'];
  $_GET['Address'];
  $_GET['Phone_Number'];
  $_GET['Gender'];
  
   $_GET['StaffID'];



  if(isset($_GET['btnUpdate']))
   {

    $name=$_GET['Name'];
    $dob=$_GET['Date_of_Birth'];
    $pass=$_GET['Password'];
    $email=$_GET['Email'];
    $address=$_GET['Address'];
    $phonenumber=$_GET['Phone_Number'];
     $gender=$_GET['Gender'];

   $query= "UPDATE staffregister SET 
                                    Name='$name',
                                    Date_of_Birth='$dob',
                                    Password='$pass',
                                    Email='$email',
                                    Address='$address',
                                    Phone_Number='$phonenumber',
                                    Gender='$gender'
                                    WHERE StaffID='$staffid' ";

   $data=mysqli_query($connection,$query);

       if ($data)
       {
        echo "<script>alert('Staff Data Updated Successful');window.location.href='adminhome.php';</script>";
       }  

      else
      {
         echo "<font color='red'>Update Failed,Try Again </font> ";
      }
}   

 ?>


 <!DOCTYPE html>
 <html>
 <head>
  <link rel="stylesheet" type="text/css" href="staffupdate.css">
   <title>Update File</title>
 </head>

 <body>
    <form action="staffupdate.php" method="GET" enctype="multipart/form-data" >

  <div class="wrapper" >
    <div class="title" align="center">Update Form</div>
    <div class="form">

      <div class="input_field">
        <label>Staff ID</label>
       <input style="background-color:red" type="text" name="StaffID" readonly class="input" value="<?php echo $_GET['StaffID']; ?>" >
      </div>


      <div class="input_field">
        <label>Email</label>
        <input style="background-color:red" type="Email" name="Email"  class="input" value="<?php echo $_GET['Email']; ?>" readonly >
      </div>

      <div class="input_field">
        <label>Full Name</label>
        <input type="text" name="Name" class="input" value="<?php echo $_GET['Name']; ?>" >
      </div>

      <div class="input_field">
        <label> Date of Birth</label>
        <input type="text" name="Date_of_Birth" class="input" value="<?php echo $_GET['Date_of_Birth']; ?>" >
      </div>

      <div class="input_field">
        <label>Password</label>
        <input type="text" name="Password" class="input" value="<?php echo $_GET['Password']; ?>" >
      </div>


      <div class="input_field">
        <label>Address</label>
        <input type="text" name="Address" class="input" value="<?php echo $_GET['Address'];?>"  >
      </div>

      <div class="input_field">
        <label>Contract</label>
        <input type="text" name="Phone_Number" class="input" value="<?php echo $_GET['Phone_Number']; ?>" >
      </div>

      <div class="input_field">
        <label>Gender</label>
        <div class="customer_select">
          <select name="Gender">
          <option value="Male"  
          <?php 
            if ( $_GET['Gender'] == "Male") 
            {
              echo "checked";
            }
           ?>
          >Male</option>
          <option value="Female" <?php 
            if ($_GET['Gender'] == "Female") 
            {
              echo "checked";
            }
           ?>
           >Female</option>
          </select>
        </div>
      </div>



      <div class="input_field">
        <input type="submit" name="btnUpdate" value="Update" class="btn"> 
        <input type="reset" name="btncancel" value="Cancel" class="btn" onclick="ClearText();" > 
       
            
      </div>
      
  <label class="btn"><a href="adminhome.php">Back</a></label>
    </div>
  </div> 
  
         
  </form>
  
 
 
 </body>