

	<?php 
	session_start();
	include 'connection.php';

	
	$Email=$_SESSION['Email'];

 
 		$query="SELECT * FROM staffregister WHERE Email='$Email' ";
 		$data=mysqli_query($connection,$query);
 		 $total=mysqli_num_rows($data); 

 	 
 		

 		while ($result=mysqli_fetch_assoc($data))
			 {

 			
 			
 						$StaffID=$result['StaffID'];
 						$Name=$result['Name'];
 						$Date_of_Birth=$result['Date_of_Birth'];
 						$Password=$result['Password'];
 						$Email=$result['Email'];
 						$Address=$result['Address'];
 						$Phone_Number=$result['Phone_Number'];
 						$Gender=$result['Gender'];
 						
 				 
 		}
 	

  ?> 



 <!DOCTYPE html>
 <html>
 <head>
 	<link rel="stylesheet" type="text/css" href="staffinformation.css">
 	<title>Staff Information</title>
 </head> 
 <body>

 	<header>
 	<div class="wrapper">
			<div class="logo" align="center">
				<img src="onlinetaxi1.jpg" alt="">
			</div>
			
			<ul class="nav-area">
				<li><a>View Data</a>
					<ul>
						<li><a href="userdata.php">User Data</a></li>
						<li><a href="staffdata.php">Driver Data</a></li>
					</ul>
				</li>
				
				<li><a href="history.php">View History</a></li>
				<li><a href="role.php">Role Registration</a></li>
				
				
				<li><a>About Vehicle</a>
					<ul>
						<li><a href="vehicle.php">Vehicle Registration</a></li>
						<li><a href="vehicle_view.php">View Vehicle</a></li>
						<li><a href="using_vehicle.php">Using Vehicle</a></li>
						<li><a href="return_vehicle.php">Return Vehicle</a></li>
						<li><a href="stafflogin.php">Logout</a></li>
					</ul>
				</li>
			</ul>


		</div>
	</header>
 <form> 
 	<table>

 	<tr>
        <td>Staff ID</td>
       <td> <input type="text" name="StaffID" readonly class="input" value="<?php echo $StaffID ?>" > </td>
     </tr>

     <tr>
        <td>Name</td>
        <td> <input type="text" name="Name" readonly class="input" value="<?php echo $Name ?>" > </td>
     </tr>

     <tr>
        <td>Date of Birth</td>
       <td>  <input type="text" name="Date_of_Birth" readonly class="input" value="<?php echo $Date_of_Birth ?>" ></td>
     </tr>

     <tr>
        <td>Password</td>
        <td> <input type="text" name="Password" readonly class="input" value="<?php echo $Password ?>" ></td>
     </tr>

     <tr>
        <td>Email</td>
      <td>   <input type="text" name="Email" readonly class="input" value="<?php echo $Email ?>" ></td>
     </tr>

     <tr>
        <td>Address</td>
       <td>  <input type="text" name="Address" readonly class="input" value="<?php echo $Address ?>" ></td>
     </tr>

     <tr>
        <td>Phone Number</td>
       <td>  <input type="text" name="Phone_Number" readonly class="input" value="<?php echo $Phone_Number ?>" ></td>
     </tr>

     <tr>
        <td>Gender</td>
       <td>  <input type="text" name="Gender" readonly class="input" value="<?php echo $Gender ?>" ></td>
     </tr>

     <tr>
     <td class="td">	<?php    echo "<a href='staffupdate.php?StaffID=$StaffID &
 							Name=$Name &
 							Date_of_Birth=$Date_of_Birth &
 							Password=$Password &
 							Email=$Email &
 							Address=$Address &
 							Phone_Number=$Phone_Number &
 							Gender=$Gender '>Edit</a>";  	?> </td>

     </tr>
 	</table>
 	

 </form>
 </body>
 </html> 

 