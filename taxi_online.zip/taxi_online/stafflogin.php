<?php 
	session_start();
	include 'connection.php';
	
	 

	if (isset($_POST['btnlogin'])) 
	{
		$EmailAddress=$_POST['Email'];
		$Password=$_POST['Password'];

		$select="SELECT * from staffregister  
		where Email='$EmailAddress' 
		and Password='$Password'";

    	$run=mysqli_query($connection,$select);
    	$count=mysqli_num_rows($run);



		if ($count>0)
     	{
         $row=mysqli_fetch_array($run);
         $RoleID=$row[0];
         $_SESSION['RoleID']=$RoleID;
	     }
		

		$query="SELECT * FROM staffregister
		 WHERE Email='$EmailAddress' 
		 AND Password='$Password'";

	    $result=mysqli_query($connection,$query);
	    $count=mysqli_num_rows($result);
	    $array=mysqli_fetch_array($result);


		if (mysqli_num_rows($result) == 1) 
		{
			

			$query = "SELECT * FROM staffregister
			 WHERE Email='$EmailAddress' 
			 AND Password='$Password'";

			$roles = mysqli_query($connection,$query);
			$row = mysqli_fetch_array($roles);

			if ($row['RoleID'] == '1')
			 {
				$_SESSION['Email'] = $EmailAddress;

				echo "<script>alert('Welcome Admin $EmailAddress');window.location.href='adminhome.php';</script>";
			} 
			elseif ($row['RoleID'] == '2') 
			{
				$_SESSION['Email'] = $EmailAddress;
				echo "<script>alert('Welcome Driver $EmailAddress');window.location.href='viewrent.php';</script>";
			}

			
			
			}
		else
		{
			echo "<script>alert('Invalid Login,Try Again')</script>";
		}
		
	}
 ?>

<!DOCTYPE html>
 <html>
 <head>

  <title> Login Form</title>
  <link rel="stylesheet" type="text/css" href="staffcss.css">
  <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
 </head>
 <body>
 	<div class="container">
 		<div class="header">
 			<h1>Staff Login</h1>
 		</div>
 		<div class="main">
 			<form action="stafflogin.php" method="POST">
 				<span>
 					<i class="fa fa-envelope" ></i>
 					<input type="text" name="Email" placeholder="Email" required>
 				</span> <br>
 				<span>
 					<i class="fa fa-key"></i> 
 					<input type="password" name="Password" placeholder="Password" required>
 				</span> <br>
 				
 				<div class="login">
 					<input type="submit"  name="btnlogin" value="Login" > 
 				</div>
 				<a href="staff.php" color='lime'>Register Here!</a>
 			</form>
 		</div>
 	</div>
 </body>
 </html>

<!-- 
<body>
  <div class="form-container">
    <form action="stafflogin.php" method="POST">
    <div class="user-img"></div>
    <ul class="list">
      <li><input type="text" name="Email" placeholder="Email" required></li>
      <li><input type="password" name="Password" placeholder="........." required></li>
      <li><input type="submit" name="btnlogin" value="Login" >
      <input type="reset" name="btncancel" value="Cancel" onclick="ClearText();" ></li>
      <li> <a href="staff.php" color='lime'>Register Here!</a></li>

      <h1 color='Yellow'> Staff Login Form</h1> 

    </ul>


  </div>  
  </form>
 </body> -->