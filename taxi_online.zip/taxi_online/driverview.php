<?php
 session_start();
include 'connection.php';

$RentID=$_SESSION['RentID'];
$UserID=$_SESSION['UserID'];


$query="SELECT * FROM private_rent p, userregister u
where p.UserID=u.UserID";
 $data=mysqli_query($connection,$query);
    $total=mysqli_num_rows($data);

    

  if ($total != 0)
    {
    	?>
    	<ins ><h2 align="center" style="color:blue"><b> DRIVER VIEW</b></h2></ins>
    	<table cellpadding="2px" border="2px" align="center" align="center" bgcolor="navyblue" style="color:white">
		<tr>
			<th>Pick_up_Address</th>
			<th>Drop_off_Address</th>
			<th>Fees</th>
			<th>RentID</th>
			<th>Status</th>

		</tr>
		<?php 
			while ($result=mysqli_fetch_assoc($data))
			 {
			 	echo "<tr>

					<td>".$result['Pick_up_address']."</td>
					<td>".$result['Drop_off_address']."</td>
					<td>".$result['Fees']."</td>
					<td>".$result['RentID']."</td>
					<td>".$result['Status']."</td>
				
					</tr>";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Driver view</title>
	
</head>
<body>
	
	
</body>
</html>